import { runCompletion } from './ai.js';
import { remember } from './memory.js';

/**
 * Delegate a task to a sub-agent Rex.
 * Used by /swarm command and the Lab > Swarm menu.
 * @param {{ task: string }} opts
 * @returns {Promise<string>} result text
 */
export async function delegate_task({ task }) {
    if (!task || typeof task !== 'string' || !task.trim()) {
        return 'No task provided for the swarm sub-agent.';
    }

    const messages = [
        {
            role: 'system',
            content: 'You are a focused sub-agent Rex. Complete the task precisely and return only the result. Be concise and useful.'
        },
        {
            role: 'user',
            content: task.trim()
        }
    ];

    try {
        const result = await runCompletion(messages, null, 'high');
        const trimmed = String(result || '').trim();

        // Save result to project memory for retrieval later
        if (trimmed) {
            try {
                remember(`Swarm sub-task result for "${task.slice(0, 80)}":\n${trimmed.slice(0, 500)}`);
            } catch {}
        }

        return trimmed || 'Sub-agent returned no output.';
    } catch (e) {
        return `Swarm sub-agent failed: ${e.message}`;
    }
}
